package client;

public class Test {

		 public static void main(String[] args) {
			 System.out.println("client down");
//			 Down down = new Down();
//			 down.start();
			 Push push = new Push();
			 push.start();
	}
}
