package client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Down extends Thread{

	public Down() {
	}
	
	public void run() {
        //        File[] files = new File("E:\\wan\\testfile").listFiles();
        //如果是多个文件，只需要把文件放入一个list或者数组中，使用for循环把数组的文件全部上传到服务器
		System.out.println("client down run");
	        try {
	            Socket socket = new Socket("192.168.43.107", 9090);
	    		System.out.println(socket.getInetAddress());
	    		
	    		OutputStream outputStream = socket.getOutputStream();
	            //使用DataOutputStream
	            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
	            //向服务器端传
	            dataOutputStream.writeUTF("down");
	            dataOutputStream.flush();//刷新流，传输到服务端

	        	InputStream inputStream = socket.getInputStream();
	        	//使用DataInputStream包装输入流
	            DataInputStream dataInputStream = new DataInputStream(inputStream);

	            String fileName = dataInputStream.readUTF();
	            System.out.println("client接收文件：" );
	            System.out.println(fileName);//在控制台显示文件名
	            //客户端下载文件目录
	            String path = ( "/root/contest/down" + File.separator + fileName); 
	            System.out.println(path);
	            File file = new File(path);
	    		if(!file.exists()){
	    			file.createNewFile();
	    			System.out.println("client create file");
	    		}
	            
	            //往某个位置写入文件
	            FileOutputStream fileOutputStream = new FileOutputStream(path);
	            int c = -1;
	            System.out.println("client 接收中！");
	            while ((c = dataInputStream.read()) != -1) {
	                fileOutputStream.write(c);
	                fileOutputStream.flush();
	            }

	            System.out.println("client文件接收成功！");
	            fileOutputStream.close();
	            dataInputStream.close();
	            dataOutputStream.close();
	            socket.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        
	}
}
