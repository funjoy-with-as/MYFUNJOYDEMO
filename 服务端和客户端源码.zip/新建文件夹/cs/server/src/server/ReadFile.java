package server;

import java.io.FileWriter;
import java.io.File;
import java.io.IOException;

public class ReadFile {
        public ReadFile() {
        }
        /**
         * 读取某个文件夹下的所有mp4文件
         */
        
        public void  readfile(String filepath, File fileList) {
                        File file = new File(filepath);
                        try {
                                String[] filelist = file.list();
                                for (int i = 0; i < filelist.length; i++) {
                                        File readfile = new File(filepath + "/" + filelist[i]);
                                        if (!readfile.isDirectory()) {
                                               // System.out.println("path=" + readfile.getPath());
//                                                System.out.println("absolutepath="
//                                                                + readfile.getAbsolutePath()); 
                                        	if(readfile.getName().endsWith(".mp4")){
                                        		if(fileList.exists()) {
                                        			//向传入的fileList文件写入视频名称
                                        		 FileWriter fileWritter = new FileWriter(fileList.getAbsoluteFile(), true);
                                                 fileWritter.write(readfile.getName());
                                                 fileWritter.write("\n");
                                                 fileWritter.close(); 
                                        		System.out.println("name=" + readfile.getName());
                                        		} else {
                                        			System.out.println("file list is empty");
                                        		}
                               			}
                                }
                        }  
                        }catch(IOException e){
                            e.printStackTrace();
                        }
        }

        /**
         * 删除某个文件夹下的所有文件夹和文件
         */
        
        
        /*public static boolean deletefile(String delpath)
                        throws FileNotFoundException, IOException {
                try {

                        File file = new File(delpath);
                        if (!file.isDirectory()) {
                                System.out.println("1");
                                file.delete();
                        } else if (file.isDirectory()) {
                                System.out.println("2");
                                String[] filelist = file.list();
                                for (int i = 0; i < filelist.length; i++) {
                                        File delfile = new File(delpath + "\\" + filelist[i]);
                                        if (!delfile.isDirectory()) {
                                                System.out.println("path=" + delfile.getPath());
                                                System.out.println("absolutepath="
                                                                + delfile.getAbsolutePath());
                                                System.out.println("name=" + delfile.getName());
                                                delfile.delete();
                                                System.out.println("删除文件成功");
                                        } else if (delfile.isDirectory()) {
                                                deletefile(delpath + "\\" + filelist[i]);
                                        }
                                }
                                file.delete();

                        }

                } catch (FileNotFoundException e) {
                        System.out.println("deletefile()   Exception:" + e.getMessage());
                }
                return true;
        }*/
       

}