package server;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * @author StarsOne
 * @date Create in  2019/4/15 0015 14:17
 * @description
 */
class AcceptThread extends Thread {
    private Socket socket;
    private InputStream inputStream;
    private OutputStream outputStream;

    public AcceptThread(Socket s) {
        this.socket = s;
    }
    
    private void acceptFile(DataInputStream dataInputStream) {
    	 try {
             //使用DataInputStream包装输入流
//    		 this.inputStream = socket.getInputStream();
//             DataInputStream dataInputStream = new DataInputStream(inputStream);
    		 System.out.println("acceptfile" );
             String fileName = dataInputStream.readUTF();
             System.out.println("服务器接收文件：" );
             System.out.println(fileName);//在控制台显示文件名

             String path = ( "/root/contest/down" + File.separator + fileName); 
             System.out.println(path);
             File file = new File(path);
     		if(!file.exists()){
     			file.createNewFile();
     			System.out.println("server create file");
     		}
             
             //往某个位置写入文件
             FileOutputStream fileOutputStream = new FileOutputStream(path);
             int c = -1;
             System.out.println("server 接收中！");
             while ((c = dataInputStream.read()) != -1) {
                 fileOutputStream.write(c);
                 fileOutputStream.flush();
             }

             System.out.println("服务器文件接收成功！");
             fileOutputStream.close();
             dataInputStream.close();
             socket.close();
         } catch (IOException e) {
             e.printStackTrace();
         }
     }
    
    private File VideoFile() {
    	try {
    	ReadFile file = new ReadFile();
    	//服务器新建视频名字列表文件
    	 String path = ( "/root/contest" + File.separator + "fileNameList.txt"); 
         System.out.println(path);
         File fileList = new File(path);
        
            //true = append file   
 		if(!fileList.exists()){
 			fileList.createNewFile();
 			System.out.println("client create fileList");
 		}
    	 file.readfile("/root/contest", fileList);
    	 return fileList;
    } catch(IOException e){
        e.printStackTrace();
    }
    	return null;
    }
    
    private void pushFile() {
        //推送的文件
        File file = VideoFile();

        try{
            this.outputStream = socket.getOutputStream();
            //使用DataOutputStream
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            //向服务器端传文件名
            
     		System.out.println(file.getName());
     		
            dataOutputStream.writeUTF(file.getName());
            dataOutputStream.flush();//刷新流，传输到服务端

            //向服务器端传文件，通过字节流
            //字节流先读取硬盘文件
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
            
            int c = -1;
            System.out.println("Client 准备上传！");
            while ((c=bufferedInputStream.read())!=-1) {
            	//System.out.println("Client 上传中！");
                //将读取的文件以字节方式写入DataOutputStream，之后传输到服务端
                //这里也可以使用byte[]数据进行读取和写入
                dataOutputStream.write(c);
                dataOutputStream.flush();
            }
            System.out.println(" 服务器 文件传输结束！");
            bufferedInputStream.close();
            dataOutputStream.close();
            System.out.println(" 服务器 文件传输成功！");
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void run() {
    	try {
    	 this.inputStream = socket.getInputStream();
         DataInputStream dataInputStream = new DataInputStream(inputStream);

         String opreate = dataInputStream.readUTF();
         System.out.println(opreate);
         switch (opreate) {
         	case "down":
         		pushFile();
         	case "push":
         		acceptFile(dataInputStream);   	 
         }
    }catch (IOException e) {
            e.printStackTrace();
        }
    }
    	
       
}
