package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author StarsOne
 * @date Create in  2019-4-14 0014 10:53:58
 * @description
 */
class Server {  
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(9090)){

            System.out.println("服务器已启动...");
            
            while (true) {
                System.out.println("等待接收文件");
                //调用了accept方法之后，会一直处于等待接受文件的状态
                Socket socket = serverSocket.accept();//接收客户端传来的数据
                //交给后台线程处理
                new AcceptThread(socket).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}