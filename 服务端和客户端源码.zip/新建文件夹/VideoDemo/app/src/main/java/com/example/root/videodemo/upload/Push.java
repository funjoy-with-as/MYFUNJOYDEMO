package com.example.root.videodemo.upload;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.os.Build;
import android.widget.Toast;

import com.example.root.videodemo.VideoAdapter.VideoLab;

import java.io.*;
import java.net.Socket;

public class Push extends Thread{
    String mFileName;
    String serverURL = "192.168.43.145";//服务器地址
    int PORT = 9090;

    public void setFile(String fileName){
        this.mFileName =fileName;
    }
    public void run(){
        Log.i("Push", "进入push");
        try{
            File file = new File(mFileName);
            Socket socket = new Socket(serverURL, PORT);
            System.out.println(socket.getInetAddress());

            OutputStream outputStream = socket.getOutputStream();
            //使用DataOutputStream
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);

            //向服务器端传文件名
            dataOutputStream.writeUTF(file.getName());
            dataOutputStream.flush();//刷新流，传输到服务端

            //向服务器端传文件，通过字节流
            //字节流先读取硬盘文件
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));

            int c = -1;
            //System.out.println("Client 准备上传！");
            while ((c=bufferedInputStream.read())!=-1) {
                //System.out.println("Client 上传中！");
                //将读取的文件以字节方式写入DataOutputStream，之后传输到服务端
                //这里也可以使用byte[]数据进行读取和写入
                dataOutputStream.write(c);
                dataOutputStream.flush();
            }
            //System.out.println(" Client 文件上传结束！");
            VideoLab.newInstance().addVideo("http://"+serverURL+":8080/examples/"+file.getName());
            bufferedInputStream.close();
            dataOutputStream.close();
            //System.out.println(" Client 文件上传成功！");
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

