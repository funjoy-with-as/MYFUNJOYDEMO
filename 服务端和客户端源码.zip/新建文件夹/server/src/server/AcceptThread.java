package server;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author StarsOne
 * @date Create in  2019/4/15 0015 14:17
 * @description
 */
class AcceptThread extends Thread {
    private InputStream inputStream;

    public AcceptThread(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    @Override
    public void run() {
        try {
            //使用DataInputStream包装输入流
            DataInputStream dataInputStream = new DataInputStream(inputStream);

            String fileName = dataInputStream.readUTF();
            System.out.println("服务器接收文件：" );
            System.out.println(fileName);//在控制台显示文件名

            String path = ( "/home/zhangzhe/Documents/tomcat/apache-tomcat-9.0.19/webapps/examples" + File.separator + fileName); 
            System.out.println(path);
            File file = new File(path);
    		if(!file.exists()){
    			file.createNewFile();
    			System.out.println("server create file");
    		}
            
            //往某个位置写入文件
            FileOutputStream fileOutputStream = new FileOutputStream(path);
            int c = -1;
            System.out.println("server 接收中！");
            while ((c = dataInputStream.read()) != -1) {
                fileOutputStream.write(c);
                fileOutputStream.flush();
            }

            System.out.println("服务器文件接收成功！");
            fileOutputStream.close();
            dataInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
