package com.example.root.videodemo.fragemnt;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.root.videodemo.VideoAdapter.VideoAdapter;
import com.example.root.videodemo.VideoAdapter.VideoLab;
import com.example.root.videodemo.VideoAdapter.MyVideo;
import com.example.root.videodemo.R;


import java.util.ArrayList;

public class VideoFragment extends Fragment{
    private static final String ARG_VIDEO_URL = "video_url";



    private RecyclerView.Adapter mAdapter;
    private RecyclerView mRecyclerView;
    private LinearLayoutManager  mLayoutManager;
    private VideoLab videoLab = new VideoLab();
    private ArrayList<MyVideo> mMyVideos = videoLab.getMyVideos();

    public VideoFragment(){

    }

    public static VideoFragment newInstance(String videoUrl){
        //创建fragment argument
        //首先创建Bundle对象
        Bundle args = new Bundle();
        //然后使用Bundle限定类型的put方法，将argument添加到bundle中
        args.putSerializable(ARG_VIDEO_URL, videoUrl);

        VideoFragment fragment = new VideoFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_video_list, container, false);
        return v;
    }

    @Override
    public void onStart(){
        super.onStart();
        mRecyclerView = (RecyclerView) getActivity().findViewById(R.id.video_recycler_view);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        mRecyclerView.setAdapter(mAdapter = new VideoAdapter(getContext(), mMyVideos));
        Log.i("你好","hahahaha");

    }

}
