package com.example.root.videodemo.fragemnt;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.root.videodemo.R;

public class SelfFragment extends android.support.v4.app.Fragment {
    TextView tvName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_self, container, false);
        init();
        return view;
    }


    public void init(){

    }
}
