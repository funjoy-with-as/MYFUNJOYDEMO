package com.example.douyin.VideoLists;

public class Bean {
    public String url;

    public Bean() {
    }

    public Bean(String url) {
        this.url = url;
    }
}
